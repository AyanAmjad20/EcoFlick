/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecoflick.ecoflickapplication;

import java.io.IOException;
import javafx.fxml.FXML;

/**
 *
 * @author rosepagano
 */
public class friendControllerClass {
    @FXML
    private void switchToView() throws IOException {
        App.setRoot("viewfriendrequests");
    }
    @FXML
    private void switchToAdd() throws IOException {
        App.setRoot("sendfriend");
    }
    @FXML
    private void switchToProfile() throws IOException {
        App.setRoot("profile");
    }
}

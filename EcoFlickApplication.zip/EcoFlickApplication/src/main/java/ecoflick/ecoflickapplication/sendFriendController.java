/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecoflick.ecoflickapplication;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author rosepagano
 */
public class sendFriendController {
    @FXML
    private TextField friendsUserName;
    @FXML
    private Label label;
    
    public void initialize()throws IOException{
    label.setText("");
    }
    
    
    @FXML
    private void sendFriendRequest() throws IOException {
        if(AccountDataBase.containsName(friendsUserName.getText())){
            label.setText("Account Exists!");
        }
        else{
            label.setText("Account does not exist!");
        }
        
    }
    @FXML
    private void switchToFriend() throws IOException {
        App.setRoot("friend");
    }
}

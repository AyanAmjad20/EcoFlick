/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecoflick.ecoflickapplication;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.scene.control.PasswordField;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;

/**
 *
 * @author rosepagano
 */
public class SignUpController {
    
    @FXML
    private PasswordField passwordPasswordField;

    @FXML
    private TextField usernameTextField;
    
    @FXML
    private Label label;
    
    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary");
    }
    
    @FXML
    private void createAccount() throws IOException {
        UserInfo.username = usernameTextField.getText();
        UserInfo.password = passwordPasswordField.getText();
        if(UserInfo.username.equals("") || UserInfo.password.equals("")||UserInfo.username.equals(" ") || UserInfo.password.equals(" ")){	
            label.setText("Must Enter Username and Password!");
        }
        else if(AccountDataBase.containsName(UserInfo.username)){
            label.setText("Username already taken!");
            
        }
        else{
            AccountDataBase.addAccount(UserInfo.username, UserInfo.password);
            label.setText("Account Created!");
            App.setRoot("profile");
        }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecoflick.ecoflickapplication;
import java.util.ArrayList;

/**
 *
 * @author rosepagano
 */
public class AccountDataBase {
    /**
     * This class is a class with an ArrayList of all the Accounts in the App
     */
    static ArrayList<Account> accountList = new ArrayList<Account>();
    public static void addAccount(String username, String password){
        accountList.add(new Account(username, password));
    }
    public static boolean containsName(String name){ 
        boolean b = false;
        for(Account i: accountList){
            if(i.getUsername().equals(name)){
                b = true;
            }
        }
        return b;
    }
    public static boolean checkPassword(String name, String pass){ 
        boolean b = false;
        for(Account i: accountList){
            if(i.getUsername().equals(name) && i.getPassword().equals(pass)){
                b = true;
            }
        }
        return b;
    }
    
    
    public static int getAccountIndex(String name){ 
        int x = -1;
        for(Account i: accountList){
            x++;
            if(i.getUsername().equals(name)){
                return x;
            }
        }
        return x;
    }
    
    @Override
    public String toString(){
        String s = "";
        for(Account i: accountList){
           s = s +"Username: "+ i.getUsername() + " Password: "+i.getPassword() + "\n"; 
        }
        return s;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecoflick.ecoflickapplication;

import java.util.ArrayList;

/**
 *
 * @author rosepagano
 */
public class Account {
    private String username;
    private String password;
    private int points;
    ArrayList<String> friends = new ArrayList<String>();
    ArrayList<String> friendRequests = new ArrayList<String>();
    Account(String username, String password){
        points = 0;
        this.username = username;
        this.password = password;
    }
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }
    public int getPoints(){
        return points;
    }
    public void addPoints(int amount){
        points += amount;
    }
    //Make boolean true if successful, false if account doesn't exist
    public boolean sendFriendRequest(String name){
    if(AccountDataBase.containsName(name)){
        AccountDataBase.accountList.get(AccountDataBase.getAccountIndex(name)).friendRequests.add(this.username);
        return true;
    }
    else{
        return false;
    }
    
    }
    public void acceptFriendRequest(int i){
        String tempUsername = friendRequests.get(i);
        //Add friend to this accounts list
        this.friends.add(friendRequests.get(i));
        this.friendRequests.remove(i);
        //Add friend to other accounts list
        AccountDataBase.accountList.get(AccountDataBase.getAccountIndex(tempUsername)).friends.add(this.username);
    
    
    
    }
    public void declineFriendRequest(int i){
    this.friendRequests.remove(i);
    
    }
    
    
    
}

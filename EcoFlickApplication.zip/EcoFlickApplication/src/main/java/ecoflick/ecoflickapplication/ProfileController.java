/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecoflick.ecoflickapplication;
import static ecoflick.ecoflickapplication.AccountDataBase.accountList;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

/**
 *
 * @author rosepagano
 */
public class ProfileController {
     @FXML
    private Label pointsLabel;

    @FXML
    private Label welcomeLabel;
     @FXML
    public void initialize()throws IOException{
    welcomeLabel.setText("hello " + UserInfo.username+"!");
    pointsLabel.setText("Flick Points: " + AccountDataBase.accountList.get(AccountDataBase.getAccountIndex(UserInfo.username)).getPoints());
    }
     @FXML
    private void addFriends() throws IOException {
        App.setRoot("friend");
    }
     @FXML
    private void feed() throws IOException {
        App.setRoot("feed");
    }
     @FXML
    private void post() throws IOException {
        App.setRoot("post");
    }
    @FXML
    private void leaderboard() throws IOException {
        App.setRoot("leaderboard");
    }
    @FXML
    private void logout() throws IOException {
        App.setRoot("primary");
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecoflick.ecoflickapplication;

/**
 *
 * @author rosepagano
 */
import java.io.IOException;
import javafx.fxml.FXML;
public class viewFriendRequestsController {
    @FXML
    private void accept() throws IOException {
        App.setRoot("viewfriendrequests");
    }
    @FXML
    private void decline() throws IOException {
        App.setRoot("sendfriend");
    }
    @FXML
    private void back() throws IOException {
        App.setRoot("profile");
    }
}

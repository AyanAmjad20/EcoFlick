package ecoflick.ecoflickapplication;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class SecondaryController {
    @FXML
    private PasswordField passwordPasswordField;
    
    @FXML
    private TextField usernameTextField;
    
    @FXML
    private Label label;
    @FXML
    private Label welcomeLabel;
    @FXML
    private Label pointsLabel;

    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary");
    }
    @FXML
    private void Login() throws IOException {
        label.setText("Test!");
        UserInfo.username = usernameTextField.getText();
        UserInfo.password = passwordPasswordField.getText();
        if(AccountDataBase.containsName(UserInfo.username)){
            if(AccountDataBase.checkPassword(UserInfo.username, UserInfo.password)){
                label.setText("Correct!");
                App.setRoot("profile");
            }
            else{
                label.setText("Incorrect password, try again");
            }
            
        }
        else{
            label.setText("No account found, try again");
        }
    }
}

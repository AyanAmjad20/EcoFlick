module ecoflick.ecoflickapplication {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens ecoflick.ecoflickapplication to javafx.fxml;
    exports ecoflick.ecoflickapplication;
}
